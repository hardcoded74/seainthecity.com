<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://www.altertech.it/
 * @since    1.2.4
 *
 * @package    Woocommerce_Alter_Inventory
 * @subpackage Woocommerce_Alter_Inventory/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
