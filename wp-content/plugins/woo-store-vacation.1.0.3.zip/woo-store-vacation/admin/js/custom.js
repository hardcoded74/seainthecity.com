(function($) {
    $(function() {
		$( '.woo-store-vacation-datepicker' ).datepicker({
                dateFormat : 'dd-mm-yy',
                minDate: 1,
        });
    }); // end of document ready
})(jQuery); // end of jQuery name space